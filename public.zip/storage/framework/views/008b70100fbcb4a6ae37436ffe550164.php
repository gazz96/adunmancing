

<?php $__env->startSection('content'); ?>
    <!-- Page content -->
    <main class="content-wrapper">
        <div class="container">

            <!-- Breadcrumb -->
            <nav class="position-relative pt-3 mt-3 mt-md-4 mb-4" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('shop')); ?>">Shop</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
                </ol>
            </nav>


            <!-- Product gallery and details -->
            <section class="row pb-4 pb-md-5 mb-2 mb-md-0 mb-xl-3">

                <!-- Gallery -->
                <div class="col-md-7 col-xl-8 pb-4 pb-md-0 mb-2 mb-sm-3 mb-md-0">
                    <div class="row row-cols-2 g-3 g-sm-4 g-md-3 g-lg-4">
                        <?php if($product->featured_image): ?>
                        <div class="col">
                            
                            <a class="hover-effect-scale hover-effect-opacity position-relative d-flex rounded-4 overflow-hidden"
                                href="<?php echo e($product->featured_image_url); ?>" data-glightbox
                                data-gallery="product-gallery">
                                <i
                                    class="ci-zoom-in hover-effect-target fs-3 text-white position-absolute top-50 start-50 translate-middle opacity-0 z-2"></i>
                                <div class="ratio ratio-1x1 hover-effect-target">
                                    <img src="<?php echo e($product->featured_image_url); ?>" alt="<?php echo e($product->name); ?>">
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            
                            <a class="hover-effect-scale hover-effect-opacity position-relative d-flex rounded-4 overflow-hidden"
                                href="<?php echo e($image->image_url); ?>" data-glightbox
                                data-gallery="product-gallery">
                                <i
                                    class="ci-zoom-in hover-effect-target fs-3 text-white position-absolute top-50 start-50 translate-middle opacity-0 z-2"></i>
                                <div class="ratio ratio-1x1 hover-effect-target">
                                    <img src="<?php echo e($image->image_url); ?>" alt="Image">
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        
                    </div>
                </div>


                <!-- Product details and options -->
                <div class="col-md-5 col-xl-4">
                    <div class="d-none d-md-block" style="margin-top: -90px"></div>
                    <div class="sticky-md-top ps-md-2 ps-xl-4">
                        <div class="d-none d-md-block" style="padding-top: 90px"></div>
                        <div class="fs-xs text-body-secondary mb-3">P<?php echo e($product->id); ?></div>
                        <h1 class="fs-xl fw-medium"><?php echo e($product->name); ?></h1>
                        <div class="h4 fw-bold mb-4"><?php echo e($product->price_label); ?> <del class="fs-sm fw-normal text-body-tertiary"><?php echo e($product->compare_price_label); ?></del>
                        </div>
                        

                        <!-- Color options -->
                        
                        <form action="<?php echo e(route('cart.add')); ?>" method="POST" id="form-add_to_cart">

                            <?php $__currentLoopData = $product->attributes ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- <?php echo e($attribute->attribute->name); ?> select -->
                            <div class="mb-4">
                                <label class="form-label fw-semibold pb-1 mb-2"><?php echo e($attribute->attribute->name); ?></label>
                                <select name="attributes[<?php echo e($attribute->attribute->name); ?>]" class="form-select form-select-lg rounded-pill"
                                    data-select='{
                                        "classNames": {
                                            "containerInner": ["form-select", "form-select-lg", "rounded-pill"]
                                        }
                                        }'
                                    aria-label="Material select">
                                    <?php $__currentLoopData = explode('|', $attribute->attribute->values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Add to cart + Wishlist buttons -->
                            <div class="d-flex gap-3 pb-4 mb-2 mb-lg-3">
                                
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <button type="submit" class="btn btn-lg btn-dark w-100 rounded-pill btn-add_to_cart">Add to cart</button>
                                
                            </div>

                        </form>

                     

                        <!-- Contact -->
                        <div class="d-flex align-items-center justify-content-between bg-body-tertiary rounded p-3">
                            <div class="me-3">
                                <h6 class="fs-sm mb-1">Have a question?</h6>
                                <p class="fs-sm mb-0">Contact us if you have questions</p>
                            </div>
                            <a class="btn btn-sm btn-outline-dark rounded-pill" href="<?php echo e(url('contact')); ?>">Contact us</a>
                        </div>
                    </div>
                </div>
            </section>


            <!-- Sticky product preview + Add to cart CTA -->
            <section class="sticky-product-banner sticky-top" data-sticky-element>
                <div class="sticky-product-banner-inner pt-5">
                    <div class="navbar flex-nowrap align-items-center bg-body pt-4 pb-2">
                        <div class="d-flex align-items-center min-w-0 ms-lg-2 me-3">
                            <div class="ratio ratio-1x1 flex-shrink-0" style="width: 50px">
                                <img src="assets/img/shop/furniture/product/thumb.png" alt="Image">
                            </div>
                            <h4 class="h6 fw-medium d-none d-lg-block ps-3 mb-0">Chair with wooden legs 60x100 cm</h4>
                            <div class="w-100 min-w-0 d-lg-none ps-2">
                                <h4 class="fs-sm fw-medium text-truncate mb-1">Chair with wooden legs 60x100 cm</h4>
                                <div class="h6 mb-0">$357.00 <del class="fs-xs fw-normal text-body-tertiary">$416.00</del>
                                </div>
                            </div>
                        </div>
                        <div class="h4 d-none d-lg-block mb-0 ms-auto me-4">$357.00 <del
                                class="fs-sm fw-normal text-body-tertiary">$416.00</del></div>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                aria-label="Add to Wishlist">
                                <i class="ci-heart fs-base animate-target"></i>
                            </button>
                            <button type="button"
                                class="btn btn-dark rounded-pill ms-auto d-none d-md-inline-flex px-4">Add to cart</button>
                            <button type="button"
                                class="btn btn-icon btn-dark rounded-circle animate-slide-end ms-auto d-md-none"
                                aria-label="Add to Cart">
                                <i class="ci-shopping-cart fs-base animate-target"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </section>


            <!-- Product description -->
            <section class="row pb-5 mb-2 mb-sm-3 mb-lg-4 mb-xl-5">
                <div class="col-md-7 col-xl-8 mb-xxl-3">
                    <div><?php echo $product->description; ?></div>
                    <ul class="list-unstyled pb-md-2 pb-lg-3">
                        <li class="mt-1"><span class="h6 mb-0">Backrest height:</span> 46 cm</li>
                        <li class="mt-1"><span class="h6 mb-0">Width:</span> 64 cm</li>
                        <li class="mt-1"><span class="h6 mb-0">Depth:</span> 78 cm</li>
                        <li class="mt-1"><span class="h6 mb-0">Height under furniture:</span> 22 cm</li>
                        <li class="mt-1"><span class="h6 mb-0">Seat width:</span> 56 cm</li>
                        <li class="mt-1"><span class="h6 mb-0">Armrest height:</span> 63 cm</li>
                    </ul>

                    <div class="accordion accordion-alt-icon" id="productAccordion">
                        <div class="accordion-item">
                            <h3 class="accordion-header" id="headingProductInfo">
                                <button type="button" class="accordion-button animate-underline fs-xl collapsed"
                                    data-bs-toggle="collapse" data-bs-target="#productInfo" aria-expanded="false"
                                    aria-controls="productInfo">
                                    <span class="animate-target me-2">Product info</span>
                                </button>
                            </h3>
                            <div class="accordion-collapse collapse" id="productInfo"
                                aria-labelledby="headingProductInfo" data-bs-parent="#productAccordion">
                                <div class="accordion-body fs-base">Introducing our Scandinavian-inspired chair,
                                    meticulously designed to infuse your living space with a touch of retro elegance.
                                    Crafted with the finest materials and attention to detail, this chair embodies the
                                    timeless charm of Scandinavian design, making it a versatile addition to any home decor.
                                    With its classic silhouette and understated sophistication, it seamlessly integrates
                                    into various interior styles, bringing both style and functionality to your room.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header" id="headingProductFeatures">
                                <button type="button" class="accordion-button animate-underline fs-xl collapsed"
                                    data-bs-toggle="collapse" data-bs-target="#productFeatures" aria-expanded="false"
                                    aria-controls="productFeatures">
                                    <span class="animate-target me-2">Features</span>
                                </button>
                            </h3>
                            <div class="accordion-collapse collapse" id="productFeatures"
                                aria-labelledby="headingProductFeatures" data-bs-parent="#productAccordion">
                                <div class="accordion-body fs-base">
                                    <ul class="m-0">
                                        <li><span class="text-body-emphasis fw-semibold">Timeless design:</span> Inspired
                                            by Scandinavian aesthetics, this chair boasts a sleek and retro-inspired
                                            silhouette that adds a touch of elegance to any space.</li>
                                        <li><span class="text-body-emphasis fw-semibold">Durable construction:</span>
                                            Crafted with high-quality materials, the chair is built to last, providing
                                            sturdy and reliable seating for years to come.</li>
                                        <li><span class="text-body-emphasis fw-semibold">Versatile placement:</span>
                                            Whether as a focal point in your living room, a cozy reading corner in your
                                            study, or an inviting seat around the dining table, this chair effortlessly
                                            adapts to different settings.</li>
                                        <li><span class="text-body-emphasis fw-semibold">Comfortable seating:</span> The
                                            chair features a well-padded seat and backrest, ensuring optimal comfort for
                                            extended periods of relaxation or conversation.</li>
                                        <li><span class="text-body-emphasis fw-semibold">Easy maintenance:</span> Designed
                                            for convenience, the chair's upholstery is easy to clean, allowing for
                                            hassle-free maintenance and care.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header" id="headingProductWarranty">
                                <button type="button" class="accordion-button animate-underline fs-xl collapsed"
                                    data-bs-toggle="collapse" data-bs-target="#productWarranty" aria-expanded="false"
                                    aria-controls="productWarranty">
                                    <span class="animate-target me-2">Warranty information</span>
                                </button>
                            </h3>
                            <div class="accordion-collapse collapse" id="productWarranty"
                                aria-labelledby="headingProductWarranty" data-bs-parent="#productAccordion">
                                <div class="accordion-body fs-base">We stand behind the quality of our products. Our chair
                                    comes with a 10-year warranty, guaranteeing against defects in materials and workmanship
                                    under normal use. In the unlikely event that you encounter any issues with your chair,
                                    contact our customer service team, and we will be happy to assist you with a replacement
                                    or repair.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header" id="headingProductDelivery">
                                <button type="button" class="accordion-button animate-underline fs-xl collapsed"
                                    data-bs-toggle="collapse" data-bs-target="#productDelivery" aria-expanded="false"
                                    aria-controls="productDelivery">
                                    <span class="animate-target me-2">Delivery and shipping</span>
                                </button>
                            </h3>
                            <div class="accordion-collapse collapse" id="productDelivery"
                                aria-labelledby="headingProductDelivery" data-bs-parent="#productAccordion">
                                <div class="accordion-body fs-base">We understand the importance of timely delivery and
                                    strive to provide a seamless shipping experience for our customers. Upon placing your
                                    order, our team will process it promptly, and you will receive a notification once your
                                    chair is ready for shipment. We offer various shipping options to accommodate your
                                    preferences, with estimated delivery times provided at checkout. Rest assured, your
                                    chair will be carefully packaged to ensure it arrives safely at your doorstep, ready to
                                    enhance your home with its timeless charm.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- Popular products carousel -->
            <section class="pb-5 mb-1 mb-sm-3 mb-lg-4 mb-xl-5">
                <h2 class="h3 pb-2 pb-sm-3">Popular products</h2>
                <div class="position-relative pb-xxl-3">

                    <!-- External slider prev/next buttons visible on screens > 500px wide (sm breakpoint) -->
                    <button type="button"
                        class="popular-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start position-absolute top-50 start-0 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                        aria-label="Prev">
                        <i class="ci-chevron-left fs-lg animate-target"></i>
                    </button>
                    <button type="button"
                        class="popular-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end position-absolute top-50 start-100 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                        aria-label="Next">
                        <i class="ci-chevron-right fs-lg animate-target"></i>
                    </button>

                    <!-- Slider -->
                    <div class="swiper"
                        data-swiper='{
              "slidesPerView": 2,
              "spaceBetween": 24,
              "loop": true,
              "navigation": {
                "prevEl": ".popular-prev",
                "nextEl": ".popular-next"
              },
              "breakpoints": {
                "768": {
                  "slidesPerView": 3
                },
                "992": {
                  "slidesPerView": 4
                }
              }
            }'>
                        <div class="swiper-wrapper">

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/04.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/04-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Bed frame light gray 140x200 cm</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$760.00</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/05.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/05-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-5" id="color-5-1" checked>
                                        <label for="color-5-1" class="btn btn-color fs-base" style="color: #3a94b5">
                                            <span class="visually-hidden">Blue</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-5" id="color-5-2">
                                        <label for="color-5-2" class="btn btn-color fs-base" style="color: #777d7E">
                                            <span class="visually-hidden">Gray</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Blue armchair with iron legs</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$220.00</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <div class="position-absolute top-0 start-0 z-2 mt-2 mt-sm-3 ms-2 ms-sm-3">
                                            <span class="badge text-bg-danger">-13%</span>
                                        </div>
                                        <img src="assets/img/shop/furniture/06.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/06-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-6" id="color-6-1" checked>
                                        <label for="color-6-1" class="btn btn-color fs-base" style="color: #bdaB9e">
                                            <span class="visually-hidden">Beige</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-6" id="color-6-2">
                                        <label for="color-6-2" class="btn btn-color fs-base" style="color: #d65c46">
                                            <span class="visually-hidden">Terracotta</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-6" id="color-6-3">
                                        <label for="color-6-3" class="btn btn-color fs-base" style="color: #e0e5eb">
                                            <span class="visually-hidden">White</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Loft-style lamp 120x80 cm</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$140.00 <del
                                            class="fs-sm fw-normal text-body-tertiary">$160.00</del></div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/08.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/08-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-8" id="color-8-1" checked>
                                        <label for="color-8-1" class="btn btn-color fs-base" style="color: #305853">
                                            <span class="visually-hidden">Green</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-8" id="color-8-2">
                                        <label for="color-8-2" class="btn btn-color fs-base" style="color: #34598f">
                                            <span class="visually-hidden">Blue</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Armchair with wooden legs 60x100 cm</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$320.50</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/02.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/02-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-2" id="color-2-1" checked>
                                        <label for="color-2-1" class="btn btn-color fs-base" style="color: #6a6f7b">
                                            <span class="visually-hidden">Gray</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-2" id="color-2-2">
                                        <label for="color-2-2" class="btn btn-color fs-base" style="color: #373b42">
                                            <span class="visually-hidden">Dark gray</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-2" id="color-2-3">
                                        <label for="color-2-3" class="btn btn-color fs-base" style="color: #216aae">
                                            <span class="visually-hidden">Blue</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-2" id="color-2-4">
                                        <label for="color-2-4" class="btn btn-color fs-base" style="color: #187c1c">
                                            <span class="visually-hidden">Green</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Decorative flowerpot with a plant</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$107.50</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/07.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/07-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-7" id="color-7-1" checked>
                                        <label for="color-7-1" class="btn btn-color fs-base" style="color: #71706c">
                                            <span class="visually-hidden">Dark gray</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-7" id="color-7-2">
                                        <label for="color-7-2" class="btn btn-color fs-base" style="color: #c1c3b8">
                                            <span class="visually-hidden">Light gray</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Chair with a cushion for the legs</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$435.00</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- External slider prev/next buttons visible on screens < 500px wide (sm breakpoint) -->
                <div class="d-flex justify-content-center gap-2 mt-1 pt-4 d-sm-none">
                    <button type="button"
                        class="popular-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start me-1"
                        aria-label="Prev">
                        <i class="ci-chevron-left fs-lg animate-target"></i>
                    </button>
                    <button type="button"
                        class="popular-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end"
                        aria-label="Next">
                        <i class="ci-chevron-right fs-lg animate-target"></i>
                    </button>
                </div>
            </section>


            <!-- Blog articles -->
            <section class="pb-5 mb-2 mb-sm-3 mb-lg-4 mb-xl-5">
                <h2 class="h3 pb-2 pb-sm-3">From the blog</h2>
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 mb-xxl-3">

                    <!-- Article -->
                    <article class="col">
                        <a class="ratio d-flex hover-effect-scale rounded-4 overflow-hidden" href="#!"
                            style="--cz-aspect-ratio: calc(260 / 306 * 100%)">
                            <img src="assets/img/blog/grid/v2/10.jpg" class="hover-effect-target" alt="Image">
                        </a>
                        <div class="pt-4">
                            <div class="nav pb-2 mb-1">
                                <a class="nav-link text-body fs-xs text-uppercase p-0" href="#!">Furniture</a>
                            </div>
                            <h3 class="h6 mb-3">
                                <a class="hover-effect-underline" href="#!">Furnishing your space: a guide to
                                    choosing the perfect furniture pieces</a>
                            </h3>
                            <div class="nav align-items-center gap-2 fs-xs">
                                <a class="nav-link text-body-secondary fs-xs fw-normal p-0" href="#!">Oliver
                                    Harris</a>
                                <hr class="vr my-1 mx-1">
                                <span class="text-body-secondary">September 5, 2024</span>
                            </div>
                        </div>
                    </article>

                    <!-- Article -->
                    <article class="col">
                        <a class="ratio d-flex hover-effect-scale rounded-4 overflow-hidden" href="#!"
                            style="--cz-aspect-ratio: calc(260 / 306 * 100%)">
                            <img src="assets/img/blog/grid/v2/11.jpg" class="hover-effect-target" alt="Image">
                        </a>
                        <div class="pt-4">
                            <div class="nav pb-2 mb-1">
                                <a class="nav-link text-body fs-xs text-uppercase p-0" href="#!">Interior design</a>
                            </div>
                            <h3 class="h6 mb-3">
                                <a class="hover-effect-underline" href="#!">Transform your living space with these
                                    chic interior design tips</a>
                            </h3>
                            <div class="nav align-items-center gap-2 fs-xs">
                                <a class="nav-link text-body-secondary fs-xs fw-normal p-0" href="#!">Ethan
                                    Miller</a>
                                <hr class="vr my-1 mx-1">
                                <span class="text-body-secondary">August 23, 2024</span>
                            </div>
                        </div>
                    </article>

                    <!-- Article -->
                    <article class="col">
                        <a class="ratio d-flex hover-effect-scale rounded-4 overflow-hidden" href="#!"
                            style="--cz-aspect-ratio: calc(260 / 306 * 100%)">
                            <img src="assets/img/blog/grid/v2/13.jpg" class="hover-effect-target" alt="Image">
                        </a>
                        <div class="pt-4">
                            <div class="nav pb-2 mb-1">
                                <a class="nav-link text-body fs-xs text-uppercase p-0" href="#!">Home decoration</a>
                            </div>
                            <h3 class="h6 mb-3">
                                <a class="hover-effect-underline" href="#!">Elevate your space with trendy home
                                    decoration ideas</a>
                            </h3>
                            <div class="nav align-items-center gap-2 fs-xs">
                                <a class="nav-link text-body-secondary fs-xs fw-normal p-0" href="#!">Olivia
                                    Anderson</a>
                                <hr class="vr my-1 mx-1">
                                <span class="text-body-secondary">August 9, 2024</span>
                            </div>
                        </div>
                    </article>
                </div>
            </section>


            <!-- Reviews -->
            <section class="pb-5 mb-2 mb-sm-3 mb-lg-4 mb-xl-5">

                <!-- Heading + Add review button -->
                <div class="d-sm-flex align-items-center justify-content-between border-bottom pb-2 pb-sm-3">
                    <div class="mb-3 me-sm-3">
                        <h2 class="h3 pb-2 mb-1">Customer reviews</h2>
                        <div class="d-flex align-items-center fs-sm">
                            <div class="d-flex gap-1 me-2">
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star text-body-tertiary opacity-75"></i>
                            </div>
                            Based on 6 reviews
                        </div>
                    </div>
                    <button type="button" class="btn btn-lg btn-outline-dark rounded-pill mb-3" data-bs-toggle="modal"
                        data-bs-target="#reviewForm">Leave a review</button>
                </div>

                <!-- Review -->
                <div class="border-bottom py-4">
                    <div class="row py-sm-2">
                        <div class="col-md-4 col-lg-3 mb-3 mb-md-0">
                            <div class="d-flex h6 mb-2">
                                Rafael Marquez
                                <i class="ci-check-circle text-success mt-1 ms-2" data-bs-toggle="tooltip"
                                    data-bs-custom-class="tooltip-sm" title="Verified customer"></i>
                            </div>
                            <div class="fs-sm mb-2 mb-md-3">June 25, 2024</div>
                            <div class="d-flex gap-1 fs-sm">
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                            </div>
                        </div>
                        <div class="col-md-8 col-lg-9">
                            <p class="mb-md-4">Absolutely love this chair! It's exactly what I was looking for to complete
                                my Scandinavian-themed living room. The wooden legs add a touch of warmth and the design is
                                timeless. Comfortable and sturdy, couldn't be happier with my purchase!</p>
                            <div class="d-sm-flex justify-content-between">
                                <div
                                    class="d-flex align-items-center fs-sm fw-medium text-dark-emphasis pb-2 pb-sm-0 mb-1 mb-sm-0">
                                    <i class="ci-check fs-base me-1" style="margin-top: .125rem"></i>
                                    Yes, I recommend this product
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="fs-sm fw-medium text-dark-emphasis me-1">Helpful?</div>
                                    <button type="button" class="btn btn-sm btn-secondary">
                                        <i class="ci-thumbs-up fs-sm ms-n1 me-1"></i>
                                        0
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Review -->
                <div class="border-bottom py-4">
                    <div class="row py-sm-2">
                        <div class="col-md-4 col-lg-3 mb-3 mb-md-0">
                            <div class="d-flex h6 mb-2">
                                Bessie Cooper
                                <i class="ci-check-circle text-success mt-1 ms-2" data-bs-toggle="tooltip"
                                    data-bs-custom-class="tooltip-sm" title="Verified customer"></i>
                            </div>
                            <div class="fs-sm mb-2 mb-md-3">April 8, 2024</div>
                            <div class="d-flex gap-1 fs-sm">
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star text-body-tertiary opacity-75"></i>
                                <i class="ci-star text-body-tertiary opacity-75"></i>
                                <i class="ci-star text-body-tertiary opacity-75"></i>
                            </div>
                        </div>
                        <div class="col-md-8 col-lg-9">
                            <p class="mb-md-4">While the design of the chair is nice and it does add a touch of retro vibe
                                to my space, I found the quality to be lacking. After just a few weeks of use, one of the
                                legs started to wobble, and the seat isn't as comfortable as I had hoped. Disappointed with
                                the durability. Additionally, the assembly process was a bit frustrating as some of the
                                screws didn't align properly with the holes, requiring extra effort to secure them in place.
                                Overall, while it looks good, I expected better quality for the price.</p>
                            <div class="d-sm-flex justify-content-between">
                                <div
                                    class="d-flex align-items-center fs-sm fw-medium text-dark-emphasis pb-2 pb-sm-0 mb-1 mb-sm-0">
                                    <i class="ci-close fs-base me-1" style="margin-top: .125rem"></i>
                                    No, I don't recommend this product
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="fs-sm fw-medium text-dark-emphasis me-1">Helpful?</div>
                                    <button type="button" class="btn btn-sm btn-secondary">
                                        <i class="ci-thumbs-up fs-sm ms-n1 me-1"></i>
                                        3
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Review -->
                <div class="border-bottom py-4">
                    <div class="row py-sm-2">
                        <div class="col-md-4 col-lg-3 mb-3 mb-md-0">
                            <div class="d-flex h6 mb-2">Savannah Nguyen</div>
                            <div class="fs-sm mb-2 mb-md-3">March 30, 2024</div>
                            <div class="d-flex gap-1 fs-sm">
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star-filled text-body-emphasis"></i>
                                <i class="ci-star text-body-tertiary opacity-75"></i>
                            </div>
                        </div>
                        <div class="col-md-8 col-lg-9">
                            <p class="mb-md-4">Great addition to our dining room! The chair looks fantastic and is quite
                                comfortable for short sits. Assembly was a breeze, and the quality seems decent for the
                                price. Overall, satisfied with the purchase.</p>
                            <div class="d-sm-flex justify-content-between">
                                <div
                                    class="d-flex align-items-center fs-sm fw-medium text-dark-emphasis pb-2 pb-sm-0 mb-1 mb-sm-0">
                                    <i class="ci-check fs-base me-1" style="margin-top: .125rem"></i>
                                    Yes, I recommend this product
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="fs-sm fw-medium text-dark-emphasis me-1">Helpful?</div>
                                    <button type="button" class="btn btn-sm btn-secondary">
                                        <i class="ci-thumbs-up fs-sm ms-n1 me-1"></i>
                                        7
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- More reviews collaspe -->
                <div class="collapse" id="moreReviews">

                    <!-- Review -->
                    <div class="border-bottom py-4">
                        <div class="row py-sm-2">
                            <div class="col-md-4 col-lg-3 mb-3 mb-md-0">
                                <div class="d-flex h6 mb-2">Daniel Adams</div>
                                <div class="fs-sm mb-2 mb-md-3">March 16, 2024</div>
                                <div class="d-flex gap-1 fs-sm">
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                </div>
                            </div>
                            <div class="col-md-8 col-lg-9">
                                <p class="mb-md-4">Couldn't be happier with this chair! It's not only stylish but also
                                    incredibly comfortable. The size is perfect for our space, and the wooden legs feel
                                    sturdy. Definitely recommend it to anyone looking for a chic and functional seating
                                    option.</p>
                                <div class="d-sm-flex justify-content-between">
                                    <div
                                        class="d-flex align-items-center fs-sm fw-medium text-dark-emphasis pb-2 pb-sm-0 mb-1 mb-sm-0">
                                        <i class="ci-check fs-base me-1" style="margin-top: .125rem"></i>
                                        Yes, I recommend this product
                                    </div>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="fs-sm fw-medium text-dark-emphasis me-1">Helpful?</div>
                                        <button type="button" class="btn btn-sm btn-secondary">
                                            <i class="ci-thumbs-up fs-sm ms-n1 me-1"></i>
                                            14
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review -->
                    <div class="border-bottom py-4">
                        <div class="row py-sm-2">
                            <div class="col-md-4 col-lg-3 mb-3 mb-md-0">
                                <div class="d-flex h6 mb-2">
                                    Jenny Wilson
                                    <i class="ci-check-circle text-success mt-1 ms-2" data-bs-toggle="tooltip"
                                        data-bs-custom-class="tooltip-sm" title="Verified customer"></i>
                                </div>
                                <div class="fs-sm mb-2 mb-md-3">February 19, 2024</div>
                                <div class="d-flex gap-1 fs-sm">
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                </div>
                            </div>
                            <div class="col-md-8 col-lg-9">
                                <p class="mb-md-4">This chair exceeded my expectations! It's well-made, comfortable, and
                                    looks even better in person. The Scandinavian design adds a sophisticated touch to my
                                    home office. I've received so many compliments already. Five stars all the way!</p>
                                <div class="d-sm-flex justify-content-between">
                                    <div
                                        class="d-flex align-items-center fs-sm fw-medium text-dark-emphasis pb-2 pb-sm-0 mb-1 mb-sm-0">
                                        <i class="ci-check fs-base me-1" style="margin-top: .125rem"></i>
                                        Yes, I recommend this product
                                    </div>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="fs-sm fw-medium text-dark-emphasis me-1">Helpful?</div>
                                        <button type="button" class="btn btn-sm btn-secondary">
                                            <i class="ci-thumbs-up fs-sm ms-n1 me-1"></i>
                                            2
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review -->
                    <div class="border-bottom py-4">
                        <div class="row py-sm-2">
                            <div class="col-md-4 col-lg-3 mb-3 mb-md-0">
                                <div class="d-flex h6 mb-2">Kristin Watson</div>
                                <div class="fs-sm mb-2 mb-md-3">February 7, 2024</div>
                                <div class="d-flex gap-1 fs-sm">
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star-filled text-body-emphasis"></i>
                                    <i class="ci-star text-body-tertiary opacity-75"></i>
                                    <i class="ci-star text-body-tertiary opacity-75"></i>
                                </div>
                            </div>
                            <div class="col-md-8 col-lg-9">
                                <p class="mb-md-4">The chair is nice, but it's not the most comfortable for extended
                                    periods of sitting. The wooden legs give it a nice aesthetic, but they seem a bit
                                    fragile. It's a decent chair for occasional use, but I wouldn't recommend it for daily
                                    use or long sitting sessions.</p>
                                <div class="d-sm-flex justify-content-between">
                                    <div
                                        class="d-flex align-items-center fs-sm fw-medium text-dark-emphasis pb-2 pb-sm-0 mb-1 mb-sm-0">
                                        <i class="ci-close fs-base me-1" style="margin-top: .125rem"></i>
                                        No, I don't recommend this product
                                    </div>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="fs-sm fw-medium text-dark-emphasis me-1">Helpful?</div>
                                        <button type="button" class="btn btn-sm btn-secondary">
                                            <i class="ci-thumbs-up fs-sm ms-n1 me-1"></i>
                                            9
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Toggle reviews collapse button -->
                <div class="nav pt-3 mt-md-2 mb-xxl-2">
                    <a class="nav-link animate-underline collapsed px-0" href="#moreReviews" data-bs-toggle="collapse"
                        aria-expanded="false" aria-controls="moreReviews" aria-label="Show / hide reviews">
                        <span class="animate-target" data-label-collapsed="Show more reviews"
                            data-label-expanded="Show less reviews"></span>
                        <i class="collapse-toggle-icon ci-chevron-down fs-base mt-1 ms-1"></i>
                    </a>
                </div>
            </section>


            <!-- Viewed products carousel -->
            <section class="pb-5 mb-2 mb-sm-3 mb-md-4 mb-lg-5">
                <h2 class="h3 pb-2 pb-sm-3">Viewed products</h2>
                <div class="position-relative pb-xxl-3">

                    <!-- External slider prev/next buttons visible on screens > 500px wide (sm breakpoint) -->
                    <button type="button"
                        class="viewed-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start position-absolute top-50 start-0 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                        aria-label="Prev">
                        <i class="ci-chevron-left fs-lg animate-target"></i>
                    </button>
                    <button type="button"
                        class="viewed-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end position-absolute top-50 start-100 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                        aria-label="Next">
                        <i class="ci-chevron-right fs-lg animate-target"></i>
                    </button>

                    <!-- Slider -->
                    <div class="swiper"
                        data-swiper='{
              "slidesPerView": 2,
              "spaceBetween": 24,
              "navigation": {
                "prevEl": ".viewed-prev",
                "nextEl": ".viewed-next"
              },
              "breakpoints": {
                "768": {
                  "slidesPerView": 3
                },
                "992": {
                  "slidesPerView": 4
                }
              }
            }'>
                        <div class="swiper-wrapper">

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/16.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/16-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-16" id="color-16-1"
                                            checked>
                                        <label for="color-16-1" class="btn btn-color fs-base" style="color: #b2b8c0">
                                            <span class="visually-hidden">Light gray</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-16" id="color-16-2">
                                        <label for="color-16-2" class="btn btn-color fs-base" style="color: #6a6662">
                                            <span class="visually-hidden">Dark gray</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Soft armchair with wooden legs</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$215.00</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/10.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/10-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-10" id="color-10-1"
                                            checked>
                                        <label for="color-10-1" class="btn btn-color fs-base" style="color: #677382">
                                            <span class="visually-hidden">Navy blue</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-10" id="color-10-2">
                                        <label for="color-10-2" class="btn btn-color fs-base" style="color: #919384">
                                            <span class="visually-hidden">Gray</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-10" id="color-10-3">
                                        <label for="color-10-3" class="btn btn-color fs-base" style="color: #b2b8c0">
                                            <span class="visually-hidden">Light gray</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Navy blue low sofa for relaxation</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$1,250.00</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/11.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/11-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-11" id="color-11-1"
                                            checked>
                                        <label for="color-11-1" class="btn btn-color fs-base" style="color: #677382">
                                            <span class="visually-hidden">Green</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-11" id="color-11-2">
                                        <label for="color-11-2" class="btn btn-color fs-base" style="color: #548294">
                                            <span class="visually-hidden">Blue</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Armchair with wooden legs 70x120 cm</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$269.99</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Item -->
                            <div class="swiper-slide">
                                <div class="animate-underline">
                                    <a class="hover-effect-opacity ratio ratio-1x1 d-block mb-3"
                                        href="shop-product-furniture.html">
                                        <img src="assets/img/shop/furniture/03.png"
                                            class="hover-effect-target opacity-100" alt="Product">
                                        <img src="assets/img/shop/furniture/03-hover.jpg"
                                            class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                            alt="Room">
                                    </a>
                                    <div class="d-flex gap-2 mb-3">
                                        <input type="radio" class="btn-check" name="colors-3" id="color-3-1" checked>
                                        <label for="color-3-1" class="btn btn-color fs-base" style="color: #a36540">
                                            <span class="visually-hidden">Brown</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-3" id="color-3-2">
                                        <label for="color-3-2" class="btn btn-color fs-base" style="color: #f8d7b5">
                                            <span class="visually-hidden">Beige</span>
                                        </label>
                                        <input type="radio" class="btn-check" name="colors-3" id="color-3-3">
                                        <label for="color-3-3" class="btn btn-color fs-base" style="color: #e0e5eb">
                                            <span class="visually-hidden">White</span>
                                        </label>
                                    </div>
                                    <h3 class="mb-2">
                                        <a class="d-block fs-sm fw-medium text-truncate"
                                            href="shop-product-furniture.html">
                                            <span class="animate-target">Home fragrance with the aroma of spices</span>
                                        </a>
                                    </h3>
                                    <div class="h6">$24.00</div>
                                    <div class="d-flex gap-2">
                                        <button type="button" class="btn btn-dark w-100 rounded-pill px-3">Add to
                                            cart</button>
                                        <button type="button"
                                            class="btn btn-icon btn-secondary rounded-circle animate-pulse"
                                            aria-label="Add to wishlist">
                                            <i class="ci-heart fs-base animate-target"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- External slider prev/next buttons visible on screens < 500px wide (sm breakpoint) -->
                <div class="d-flex justify-content-center gap-2 mt-1 pt-4 d-sm-none">
                    <button type="button"
                        class="viewed-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start me-1"
                        aria-label="Prev">
                        <i class="ci-chevron-left fs-lg animate-target"></i>
                    </button>
                    <button type="button"
                        class="viewed-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end"
                        aria-label="Next">
                        <i class="ci-chevron-right fs-lg animate-target"></i>
                    </button>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/product-detail.blade.php ENDPATH**/ ?>