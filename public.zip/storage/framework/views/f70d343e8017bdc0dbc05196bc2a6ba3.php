


<?php $__env->startSection('content'); ?>
    <!-- Page content -->
    <main class="content-wrapper">
        <div class="container py-5 mt-n2 mt-sm-0">
            <div class="row pt-md-2 pt-lg-3 pb-sm-2 pb-md-3 pb-lg-4 pb-xl-5">


                <div class="col-lg-3">
                    <?php echo $__env->make('frontend.my-account.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


                <!-- Addresses content -->
                <div class="col-lg-9">
                    <div class="ps-lg-3 ps-xl-0">

                        <!-- Page title -->
                        <h1 class="h2 mb-1 mb-sm-2">Addresses</h1>

                        <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <!-- Primary shipping address -->
                            <div class="border-bottom py-4">
                                <div class="nav flex-nowrap align-items-center justify-content-between pb-1 mb-3">
                                    <div class="d-flex align-items-center gap-3 me-4">
                                        <h2 class="h6 mb-0"><?php echo e($address->name); ?></h2>
                                        <?php if($address->is_default): ?>
                                            <span class="badge text-bg-info rounded-pill">Primary</span>
                                        <?php endif; ?>
                                    </div>
                                    <a class="nav-link hiding-collapse-toggle text-decoration-underline p-0 collapsed"
                                        href=".primary-address-<?php echo e($address->id); ?>" data-bs-toggle="collapse" aria-expanded="false"
                                        aria-controls="primaryAddressPreview primaryAddressEdit">Edit</a>
                                </div>
                                <div class="collapse primary-address show" id="primaryAddressPreview">
                                    <ul class="list-unstyled fs-sm m-0">
                                        <li><?php echo e($address->province_name); ?>, <?php echo e($address->city_name); ?>,
                                            <?php echo e($address->postal_code); ?></li>
                                        <li><?php echo e($address->address); ?></li>
                                    </ul>
                                </div>
                                <div class="collapse primary-address-<?php echo e($address->id); ?>" id="primaryAddressEdit">
                                    <form class="row g-3 g-sm-4 needs-validation" novalidate method="POST"
                                        action="<?php echo e(route('web.my-account.save-addresses')); ?>">
                                        <input type="hidden" name="id" value="<?php echo e($address->id); ?>">
                                        <input type="hidden" name="province_id" value="<?php echo e($address->province_id); ?>">
                                        <input type="hidden" name="province_name" value="<?php echo e($address->province_name); ?>">
                                        <input type="hidden" name="city_name" value="<?php echo e($address->city_name); ?>">
                                        
                                        <div class="col-sm-10">
                                            <label for="iName" class="form-label">Name</label>
                                            <input name="name" type="text" class="form-control" id="iName"
                                                value="<?php echo e($address->name); ?>" required>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="d-block invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="position-relative">
                                                <label for="ipsa-zip" class="form-label">Receipt Name</label>
                                                <input name="recipient_name" type="text" class="form-control" id="ipsa-zip"
                                                    value="<?php echo e($address->recipient_name); ?>" required>
                                                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="position-relative">
                                                <label for="iPhoneNumber" class="form-label">Phone Number</label>
                                                <input name="phone_number" type="text" class="form-control" id="iPhoneNumber" value="<?php echo e($address->phone_number); ?>" required>
                                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="col-sm-6">
                                            <div class="position-relative">
                                                <label class="form-label">City</label>
                                                <select name="city_id" class="form-select iCityId"
                                                    data-select='{"searchEnabled": true}' id="iCityId"
                                                    aria-label="Select city" required>
                                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($city->city_id); ?>"
                                                            data-option='<?php echo e(json_encode($city)); ?>'
                                                            <?php echo e($city->city_id == $address->city_id ? 'selected' : ''); ?>>
                                                            <?php echo e($city->province); ?> - <?php echo e($city->city_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="invalid-feedback">Please select your city!</div>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="position-relative">
                                                <label for="psa-zip" class="form-label">ZIP code</label>
                                                <input name="postal_code" type="text" class="form-control" id="psa-zip"
                                                    value="<?php echo e($address->postal_code); ?>" required>
                                                <div class="invalid-feedback">Please enter your ZIP code!</div>
                                            </div>
                                        </div>
                                        <div class="col-sm-10">
                                            <div class="position-relative">
                                                <label for="psa-address" class="form-label">Address</label>
                                                <input name="address" type="text" class="form-control" id="psa-address"
                                                    value="<?php echo e($address->address); ?>" required>
                                                <div class="invalid-feedback">Please enter your address!</div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-check mb-0">
                                                <input name="is_default" type="checkbox" class="form-check-input"
                                                    id="set-primary-1" value="1" <?php if($address->is_default): ?> checked <?php endif; ?>>
                                                <label for="set-primary-1" class="form-check-label">Set as primary
                                                    address</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="d-flex gap-3 pt-2 pt-sm-0">
                                                <button type="submit" class="btn btn-primary">Save changes</button>
                                                <button type="button" class="btn btn-secondary" data-bs-toggle="collapse"
                                                    data-bs-target=".primary-address-<?php echo e($address->id); ?>" aria-expanded="true"
                                                    aria-controls="primaryAddressPreview primaryAddressEdit">Close</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>


                        <!-- Add address button -->
                        <div class="nav pt-4">
                            <a class="nav-link animate-underline fs-base px-0" href="#newAddressModal"
                                data-bs-toggle="modal">
                                <i class="ci-plus fs-lg ms-n1 me-2"></i>
                                <span class="animate-target">Add address</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_scripts'); ?>
    <!-- Add new address modal -->
    <div class="modal fade" id="newAddressModal" data-bs-backdrop="static" tabindex="-1"
        aria-labelledby="newAddressModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newAddressModalLabel">Add new address</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3 g-sm-4 needs-validation" novalidate method="POST"
                        action="<?php echo e(route('web.my-account.save-addresses')); ?>">
                        <input type="hidden" name="id" value="">
                        <input type="hidden" name="province_id" value="">
                        <input type="hidden" name="province_name" value="">
                        <input type="hidden" name="city_name" value="">
                        <div class="col-sm-10">
                            <label for="iName" class="form-label">Name</label>
                            <input name="name" type="text" class="form-control" id="iName"
                                value="" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="d-block invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-6">
                            <div class="position-relative">
                                <label for="ipsa-recipient_name" class="form-label">Receipt Name</label>
                                <input name="recipient_name" type="text" class="form-control" id="ipsa-recipient_name"
                                    value="" required>
                                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="position-relative">
                                <label for="iPhoneNumber" class="form-label">Phone Number</label>
                                <input name="phone_number" type="text" class="form-control" id="iPhoneNumber" value="" required>
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="d-block invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="position-relative">
                                <label class="form-label">City</label>
                                <select name="city_id" class="form-select iCityId" data-select='{"searchEnabled":true}' aria-label="Select city" required>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->city_id); ?>" data-option='<?php echo e(json_encode($city)); ?>'>
                                            <?php echo e($city->province); ?> - <?php echo e($city->city_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback">Please select your city!</div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="position-relative">
                                <label for="ipsa-zip" class="form-label">ZIP code</label>
                                <input name="postal_code" type="text" class="form-control" id="ipsa-zip"
                                    value="" required>
                                <div class="invalid-feedback">Please enter your ZIP code!</div>
                            </div>
                        </div>
                        <div class="col-sm-10">
                            <div class="position-relative">
                                <label for="ipsa-address" class="form-label">Address</label>
                                <input name="address" type="text" class="form-control" id="ipsa-address"
                                    value="" required>
                                <div class="invalid-feedback">Please enter your address!</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-check mb-0">
                                <input name="is_default" type="checkbox" class="form-check-input" id="iset-primary-1"
                                    value="1" checked>
                                <label for="iset-primary-1" class="form-check-label">Set as primary address</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex gap-3 pt-2 pt-sm-0">
                                <button type="submit" class="btn btn-primary">Save changes</button>
                                <button type="button" class="btn btn-secondary" data-bs-toggle="collapse"
                                    data-bs-target=".primary-address" aria-expanded="true"
                                    aria-controls="primaryAddressPreview primaryAddressEdit">Close</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script>
        let cities = []
        async function initPage() {
            //const response = await App.Models.Shipping.getRegencies();
            // cities = response?.rajaongkir?.results ?? []
            //await renderCityOptions(cities)
        }


        $(document).on('change', '.iCityId', async function(e) {
            e.preventDefault();
            let cityIdToFind = $(this).val();
            const city = $(this).find('option:selected').data('option');
            console.log('city', city);
            let form = $(this).closest('form');
            form.find('[name=city_id]').val(city.city_id);
            form.find('[name=province_id]').val(city.province_id);
            form.find('[name=province_name]').val(city.province);
            form.find('[name=city_name]').val(city.city_name)

        })

        initPage();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/my-account/addresses.blade.php ENDPATH**/ ?>