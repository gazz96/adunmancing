<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-pwa="true">

<head>
    <meta charset="utf-8">

    <!-- Viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover">

    <!-- SEO Meta Tags -->
    <title><?php echo e($option->getByKey('site_name')); ?> | Furniture Store</title>
    <meta name="description" content="<?php echo e($option->getByKey('site_description')); ?>">
    <meta name="keywords"
        content="online shop, e-commerce, online store, market, multipurpose, product landing, cart, checkout, ui kit, light and dark mode, bootstrap, html5, css3, javascript, gallery, slider, mobile, pwa">
    <meta name="author" content="Bagas Topati">

    <!-- Webmanifest + Favicon / App icons -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="manifest" href="/manifest.json">
    <link rel="icon" type="image/png" href="assets/app-icons/icon-32x32.png" sizes="32x32">
    <link rel="apple-touch-icon" href="assets/app-icons/icon-180x180.png">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Theme switcher (color modes) -->
    

    <!-- Preloaded local web font (Inter) -->
    <link rel="preload" href="assets/fonts/inter-variable-latin.woff2" as="font" type="font/woff2" crossorigin>

    <!-- Font icons -->
    <link rel="preload" href="<?php echo e(url('assets/icons/cartzilla-icons.woff2')); ?>" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="<?php echo e(url('assets/icons/cartzilla-icons.min.css')); ?>">

    <!-- Vendor styles -->
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/choices.js/public/assets/styles/choices.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/flatpickr/dist/flatpickr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/swiper/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/simplebar/dist/simplebar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/glightbox/dist/css/glightbox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/sweet-alert/sweet-alert.min.css')); ?>">
    

    <!-- Bootstrap + Theme styles -->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/theme.min.css')); ?>" id="theme-styles">
</head>


<!-- Body -->

<body>

    <!-- Shopping cart offcanvas (Empty state) -->
    <div class="offcanvas offcanvas-end pb-sm-2 px-sm-2" id="shoppingCart" tabindex="-1"
        aria-labelledby="shoppingCartLabel" style="width: 500px">
        <div class="offcanvas-header py-3 pt-lg-4">
            <h4 class="offcanvas-title" id="shoppingCartLabel">Shopping cart</h4>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">

            <?php echo $__env->make('frontend.cart.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
        </div>
        <div class="offcanvas-header flex-column align-items-start">
            
            <div class="d-flex w-100 gap-3">
                <a class="btn btn-lg btn-dark w-100" href="<?php echo e(route('web.checkout')); ?>">Checkout</a>
            </div>
        </div>
    </div>


    <!-- Topbar -->
    <div class="container position-relative d-flex justify-content-between z-1 py-3">
        <div class="nav animate-underline">
            <span class="text-secondary-emphasis fs-xs me-1">Contact us <span
                    class="d-none d-sm-inline">24/7</span></span>
            <a class="nav-link animate-target fs-xs fw-semibold p-0"
                href="tel:<?php echo e($option->getByKey('contact')); ?>"><?php echo e($option->getByKey('contact')); ?></a>
        </div>
        
        <ul class="nav gap-4">
            

            <?php if(Auth::check()): ?>
                <li class="animate-underline">
                    <a class="nav-link animate-target fs-xs p-0" href="<?php echo e(route('web.my-account')); ?>">Account</a>
                </li>
            <?php else: ?>
                <li class="animate-underline">
                    <a class="nav-link animate-target fs-xs p-0"
                        href="<?php echo e(route('web.auth.login')); ?>">Login/Register</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>


    <!-- Navigation bar (Page header) -->
    <header class="navbar-sticky sticky-top container z-fixed px-2" data-sticky-element>
        <div class="navbar navbar-expand-lg flex-nowrap bg-body rounded-pill shadow ps-0 mx-1">
            <div class="position-absolute top-0 start-0 w-100 h-100 bg-dark rounded-pill z-0 d-none d-block-dark">
            </div>

            <!-- Mobile offcanvas menu toggler (Hamburger) -->
            <button type="button" class="navbar-toggler ms-3" data-bs-toggle="offcanvas"
                data-bs-target="#navbarNav" aria-controls="navbarNav" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar brand (Logo) -->
            <a class="navbar-brand position-relative z-1 ms-4 ms-sm-5 ms-lg-4 me-2 me-sm-0 me-lg-3"
                href="<?php echo e(url('/')); ?>">
                
                <?php if($logo = $option->getByKey('site_logo')): ?>
                
               <img src="<?php echo e(url('storage/' . $logo)); ?>" alt="<?php echo e($option->getByKey('site_name')); ?>" width="40">

                <?php else: ?> 
                     <?php echo e($option->getByKey('site_name')); ?>

                <?php endif; ?>
            
            </a>

            <!-- Main navigation that turns into offcanvas on screens < 992px wide (lg breakpoint) -->
            <nav class="offcanvas offcanvas-start" id="navbarNav" tabindex="-1" aria-labelledby="navbarNavLabel">
                <div class="offcanvas-header py-3">
                    <h5 class="offcanvas-title" id="navbarNavLabel">Browse Cartzilla</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
                </div>
                <div class="offcanvas-body pt-3 pb-4 py-lg-0 mx-lg-auto">
                    <ul class="navbar-nav position-relative">

                        <?php if($mainMenus->items->count() > 0): ?>
                            <?php $__currentLoopData = $mainMenus->items()->orderBy('order', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item me-lg-n2 me-xl-0">
                                    <a class="nav-link fs-sm" href="<?php echo e($menu->url); ?>"><?php echo e($menu->label); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>



                        
                    </ul>
                </div>
            </nav>

            <!-- Button group -->
            <div class="d-flex gap-sm-1 position-relative z-1">

                <!-- Theme switcher (light/dark/auto) -->
                <div class="dropdown">
                    
                    <ul class="dropdown-menu start-50 translate-middle-x"
                        style="--cz-dropdown-min-width: 9rem; --cz-dropdown-spacer: 1rem">
                        <li>
                            <button type="button" class="dropdown-item active" data-bs-theme-value="light"
                                aria-pressed="true">
                                <span class="theme-icon d-flex fs-base me-2">
                                    <i class="ci-sun"></i>
                                </span>
                                <span class="theme-label">Light</span>
                                <i class="item-active-indicator ci-check ms-auto"></i>
                            </button>
                        </li>
                        <li>
                            <button type="button" class="dropdown-item" data-bs-theme-value="dark"
                                aria-pressed="false">
                                <span class="theme-icon d-flex fs-base me-2">
                                    <i class="ci-moon"></i>
                                </span>
                                <span class="theme-label">Dark</span>
                                <i class="item-active-indicator ci-check ms-auto"></i>
                            </button>
                        </li>
                        <li>
                            <button type="button" class="dropdown-item" data-bs-theme-value="auto"
                                aria-pressed="false">
                                <span class="theme-icon d-flex fs-base me-2">
                                    <i class="ci-auto"></i>
                                </span>
                                <span class="theme-label">Auto</span>
                                <i class="item-active-indicator ci-check ms-auto"></i>
                            </button>
                        </li>
                    </ul>
                </div>

                <!-- Cart button -->
                <button type="button"
                    class="btn btn-icon fs-lg btn-outline-secondary border-0 rounded-circle animate-scale me-2"
                    data-bs-toggle="offcanvas" data-bs-target="#shoppingCart" aria-controls="shoppingCart"
                    aria-label="Shopping cart">
                    <i class="ci-shopping-cart animate-target"></i>
                </button>

                <!-- Search -->
                <div class="dropdown">
                    <button type="button" class="btn btn-icon fs-lg btn-secondary rounded-circle animate-scale"
                        data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-label="Toggle search bar">
                        <i class="ci-search animate-target"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end p-3"
                        style="--cz-dropdown-min-width: 20rem; --cz-dropdown-spacer: 1rem">
                        <form class="position-relative" action="<?php echo e(route('web.blogs')); ?>">
                            <input name="s" type="search" class="form-control rounded-pill" placeholder="Search..."
                                data-autofocus="dropdown" value="<?php echo e(request('s')); ?>">
                            <button type="submit"
                                class="btn btn-icon btn-sm fs-lg btn-secondary rounded-circle position-absolute top-0 end-0 mt-1 me-1"
                                aria-label="Search">
                                <i class="ci-arrow-right"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </header>


    <?php echo $__env->yieldContent('content'); ?>

    <!-- Page footer -->
    <footer class="footer bg-dark pb-4" data-bs-theme="dark">

      <div class="container py-4 py-md-5">
        <div class="row pt-3 pb-4 py-md-1 py-lg-3">

          <!-- Promo text + Social account links -->
          <div class="col-lg-3 text-center text-lg-start pb-sm-2 pb-md-0 mb-4 mb-md-5 mb-lg-0">
            <h4 class="pb-2 mb-1">
              <a class="text-dark-emphasis text-decoration-none" href="index.html"><?php echo e($option->getByKey('site_name')); ?></a>
            </h4>
            <p class="fs-sm text-body mx-auto" style="max-width: 480px"><?php echo e($option->getByKey('site_description')); ?></p>
            <div class="d-flex justify-content-center justify-content-lg-start gap-2 pt-2 pt-md-3">
              <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="#!" data-bs-toggle="tooltip" data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-white p-0"></div></div>' title="Instagram" aria-label="Follow us on Instagram">
                <i class="ci-instagram"></i>
              </a>
              <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="#!" data-bs-toggle="tooltip" data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-white p-0"></div></div>' title="Facebook" aria-label="Follow us on Facebook">
                <i class="ci-facebook"></i>
              </a>
              <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="#!" data-bs-toggle="tooltip" data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-white p-0"></div></div>' title="Telegram" aria-label="Follow us on Telegram">
                <i class="ci-telegram"></i>
              </a>
              <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="#!" data-bs-toggle="tooltip" data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-white p-0"></div></div>' title="WhatsApp" aria-label="Follow us on WhatsApp">
                <i class="ci-whatsapp"></i>
              </a>
            </div>
          </div>

          <!-- Columns with links that are turned into accordion on screens < 500px wide (sm breakpoint) -->
          <div class="col-lg-8 offset-lg-1">
            <div class="accordion" id="footerLinks">
              <div class="row">
                <div class="accordion-item col-sm-3 border-0">
                  <h6 class="accordion-header" id="categoriesHeading">
                    <span class="text-dark-emphasis d-none d-sm-block">Categories</span>
                    <button type="button" class="accordion-button collapsed py-3 d-sm-none" data-bs-toggle="collapse" data-bs-target="#categoriesLinks" aria-expanded="false" aria-controls="categoriesLinks">Categories</button>
                  </h6>
                  <div class="accordion-collapse collapse d-sm-block" id="categoriesLinks" aria-labelledby="categoriesHeading" data-bs-parent="#footerLinks">
                    <ul class="nav flex-column gap-2 pt-sm-3 pb-3 pb-sm-0 mt-n1 mb-1 mb-sm-0">
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Weekly sale</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Special price</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Easter is coming</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Italian dinner</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Fresh fruits</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Exotic fruits</a>
                      </li>
                    </ul>
                  </div>
                  <hr class="d-sm-none my-0">
                </div>
                <div class="accordion-item col-sm-3 border-0">
                  <h6 class="accordion-header" id="companyHeading">
                    <span class="text-dark-emphasis d-none d-sm-block">Company</span>
                    <button type="button" class="accordion-button collapsed py-3 d-sm-none" data-bs-toggle="collapse" data-bs-target="#companyLinks" aria-expanded="false" aria-controls="companyLinks">Company</button>
                  </h6>
                  <div class="accordion-collapse collapse d-sm-block" id="companyLinks" aria-labelledby="companyHeading" data-bs-parent="#footerLinks">
                    <ul class="nav flex-column gap-2 pt-sm-3 pb-3 pb-sm-0 mt-n1 mb-1 mb-sm-0">
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Blog and news</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">About us</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">FAQ page</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Contact us</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Careers</a>
                      </li>
                    </ul>
                  </div>
                  <hr class="d-sm-none my-0">
                </div>
                <div class="accordion-item col-sm-3 border-0">
                  <h6 class="accordion-header" id="accountHeading">
                    <span class="text-dark-emphasis d-none d-sm-block">Account</span>
                    <button type="button" class="accordion-button collapsed py-3 d-sm-none" data-bs-toggle="collapse" data-bs-target="#accountLinks" aria-expanded="false" aria-controls="accountLinks">Account</button>
                  </h6>
                  <div class="accordion-collapse collapse d-sm-block" id="accountLinks" aria-labelledby="accountHeading" data-bs-parent="#footerLinks">
                    <ul class="nav flex-column gap-2 pt-sm-3 pb-3 pb-sm-0 mt-n1 mb-1 mb-sm-0">
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Your account</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Shipping &amp; policies</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Refunds &amp; replacements</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Order tracking</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Delivery info</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Taxes &amp; fees</a>
                      </li>
                    </ul>
                  </div>
                  <hr class="d-sm-none my-0">
                </div>
                <div class="accordion-item col-sm-3 border-0">
                  <h6 class="accordion-header" id="customerHeading">
                    <span class="text-dark-emphasis d-none d-sm-block">Customer service</span>
                    <button type="button" class="accordion-button collapsed py-3 d-sm-none" data-bs-toggle="collapse" data-bs-target="#customerLinks" aria-expanded="false" aria-controls="customerLinks">Customer service</button>
                  </h6>
                  <div class="accordion-collapse collapse d-sm-block" id="customerLinks" aria-labelledby="customerHeading" data-bs-parent="#footerLinks">
                    <ul class="nav flex-column gap-2 pt-sm-3 pb-3 pb-sm-0 mt-n1 mb-1 mb-sm-0">
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Payment methods</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Money back guarantee</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Refunds &amp; replacements</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Order tracking</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Delivery info</a>
                      </li>
                      <li class="d-flex w-100 pt-1">
                        <a class="nav-link animate-underline animate-target d-inline fw-normal text-truncate p-0" href="#!">Shipping</a>
                      </li>
                    </ul>
                  </div>
                  <hr class="d-sm-none my-0">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Copyright -->
      <p class="container fs-xs text-body text-center text-lg-start pb-md-3 mb-0">
       <?php echo $option->getByKey('site_copyright'); ?>

      </p>
    </footer>


    <!-- Back to top button -->
    <div class="floating-buttons position-fixed top-50 end-0 z-sticky me-3 me-xl-4 pb-4">
        <a class="btn-scroll-top btn btn-sm bg-body border-0 rounded-pill shadow animate-slide-end" href="#top">
            Top
            <i class="ci-arrow-right fs-base ms-1 me-n1 animate-target"></i>
            <span class="position-absolute top-0 start-0 w-100 h-100 border rounded-pill z-0"></span>
            <svg class="position-absolute top-0 start-0 w-100 h-100 z-1" viewBox="0 0 62 32" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <rect x=".75" y=".75" width="60.5" height="30.5" rx="15.25" stroke="currentColor"
                    stroke-width="1.5" stroke-miterlimit="10" />
            </svg>
        </a>
    </div>


    <!-- Vendor scripts -->
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/flatpickr/dist/flatpickr.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/cleave.js/dist/cleave.min.js')); ?> "></script>
    <script src="<?php echo e(url('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/simplebar/dist/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/glightbox/dist/js/glightbox.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/sweet-alert/sweet-alert.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/currency.min.js')); ?>  "></script>



    <!-- Bootstrap + Theme scripts -->
    <script src="<?php echo e(url('assets/js/theme.min.js')); ?>"></script>

    <script>

            const App = {
                Models: {
                    Shipping: {
                        getProvinces: async(data = {}) => {
                            return $.ajax({
                                url: "<?php echo e(route('web.shipping.provinces')); ?>",
                                data: data
                            })
                        },
                        getRegencies: async(data) => {
                            return $.ajax({
                                url: "<?php echo e(route('web.shipping.regencies')); ?>",
                                data: data
                            })
                        },
                        getCost: async(data) => {
                            return $.ajax({
                                method: 'POST',
                                url: "<?php echo e(route('web.shipping.cost')); ?>",
                                data: data
                            })
                        },
                    }
                },
                Helper: {
                    sumPrices: function(...prices) {
                        let total = currency(0, {
                            separator:',',
                            decimal: '.',
                            precision: 0,
                            symbol: ''
                        });

                        prices.forEach(function (price) {
                            total = total.add(currency(price, {
                                separator: ',',
                                decimal: '.',
                                precision: 0,
                                symbol: ''
                            }));
                        });

                        return total.format(); // default: Rp10.000
                    }
                }
            }

            const removeCart = async(key) => {
                return await $.ajax({
                    url: "<?php echo e(route('cart.remove')); ?>",
                    method: 'POST',
                    data:{
                        key: key
                    }
                })
            }

            const addToCart = async (data) => {
                let form = $('#form-add_to_cart');
                return await $.ajax({
                    url: "<?php echo e(route('cart.add')); ?>",
                    method: 'POST',
                    data: data
                })
            }

            const refreshCart = async () => {
                try {
                    const response = await $.ajax({
                        url: "<?php echo e(route('cart.index')); ?>"
                    });
                    
                    let shoppingCartBody = $('#shoppingCart').find('.offcanvas-body')// Update cart UI with the new data
                    shoppingCartBody.html(response);
                    
                } catch (error) {
                    console.error('Error fetching cart:', error);
                }
            };

            // Add to cart form submission
            $('#form-add_to_cart').on('submit', async function(e) {
                e.preventDefault();
                await addToCart($(this).serialize());
                await refreshCart();

                await Swal.fire({
                    icon: 'success',
                    title: 'Information',
                    text: 'Product added to cart'
                })
            });

            $(document).on('click', '.btn-remove_from_cart', async function(e){
                e.preventDefault();
                await removeCart($(this).data('key'));
                await refreshCart();

                await Swal.fire({
                    icon: 'error',
                    title: 'Information',
                    text: 'Product deleted from cart'
                })

            })

            $(document).on('click', '.btn-single_add_to_cart', async function(e){
                e.preventDefault();
                await addToCart({
                    product_id: $(this).data('key')
                })
                await refreshCart();

                await Swal.fire({
                    icon: 'success',
                    title: 'Information',
                    text: 'Product added to cart'
                })
            })
    </script>

    <script>

        let courierElement = $('#iCourier');

        async function renderCosts(costs) {
            let html = `<option value=''>Pilih</option>`;
            $('#iCourierPackage').html('');

            (costs ?? []).map((value, index) => {
                value.costs.map((cost, index) => {
                    cost.cost.map((price, index) => {
                        console.log('price', price);
                         html += `<option value="${value.code}|${cost.service}|${price.value}|${price.etd}">Harga ${price.value} | ETD ${price.etd}</option>`;
                    })
                }) 
            })

            $('#iCourierPackage').html(html)
        }

        $(document).on('change', '#iCourier', async function(e){

            $('#delivery-price').val(0);
            const value = $(this).val();
            const costs = await App.Models.Shipping.getCost({
                courier: value
            });

            console.log('costs', costs);

            await renderCosts(costs?.results);
        })

        $(document).on('change', '#iCourierPackage', async function(e){
            var value = $(this).val(); // ambil value terpilih
            console.log('value', value);
            if (value) {
                let cartPrice = $('#cart-price').html();
                var parts = value.split('|');
                var price = App.Helper.sumPrices(parts[2]); // index ke-2 = harga
                let total = App.Helper.sumPrices(price, cartPrice);

                console.log('cartPrice', cartPrice);

                $('#delivery-price').html(price);
                $('#total-price').html(total);
            } else {
                $('#delivery-price').html('');
            } 

           
        })



    </script>

    <?php echo $__env->yieldContent('footer_scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/layouts/default.blade.php ENDPATH**/ ?>