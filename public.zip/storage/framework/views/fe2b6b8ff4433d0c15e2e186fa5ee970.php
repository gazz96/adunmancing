


<?php $__env->startSection('content'); ?>
    <!-- Page warpper -->
    <main class="content-wrapper">

        <!-- Post content + Sidebar sharing -->
        <section class="container pb-5 mb-2 mb-md-3 mb-lg-4 mb-xl-5">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <!-- Breadcrumb -->
                    <nav class="pt-3 my-3 my-md-4" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.blogs')); ?>">Blog</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($post->title); ?></li>
                        </ol>
                    </nav>

                    <!-- Post title -->
                    <h1 class="h3 mb-4"><?php echo e($post->title); ?></h1>

                    <!-- Post meta -->
                    <div class="nav align-items-center gap-2 border-bottom pb-4 mt-n1 mb-4">
                        
                        <span class="text-body-tertiary fs-xs">
                            <?php echo e(date('d F Y', strtotime($post->created_at))); ?>

                        </span>
                    </div>
                </div>
            </div>
            <div class="row">

                <!-- Post content -->
                <div class="col-lg-8 offset-lg-2">

                    <figure class="figure w-100 py-3 py-md-4 mb-3">
                        <div class="ratio" style="--cz-aspect-ratio: calc(599 / 856 * 100%)">
                            <img src="<?php echo e($post->featured_image_url); ?>" class="rounded-4" alt="<?php echo e($post->title); ?>">
                        </div>
                        
                    </figure>

                    <div>
                        <?php echo $post->content; ?>

                    </div>


                    <!-- Tags + Sharing -->
                    <div
                        class="d-sm-flex align-items-center justify-content-between py-4 py-md-5 mt-n2 mt-md-n3 mb-2 mb-sm-3 mb-md-0">
                        <div class="d-flex flex-wrap gap-2 mb-4 mb-sm-0 me-sm-4">
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-outline-secondary px-3 mt-1 me-1" href="#!"><?php echo e($category->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Sharing visible on screens < 992px wide (lg breakpoint) -->
                        <div class="d-flex d-lg-none align-items-center gap-2">
                            <div class="text-body-emphasis fs-sm fw-medium">Share:</div>

                            <!-- X (Twitter) Share -->
                            <a class="btn btn-icon fs-base btn-outline-secondary border-0"
                                href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(url()->current())); ?>"
                                target="_blank" data-bs-toggle="tooltip"
                                data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-body p-0"></div></div>'
                                title="X (Twitter)" aria-label="Share on X">
                                <i class="ci-x"></i>
                            </a>

                            <!-- Facebook Share -->
                            <a class="btn btn-icon fs-base btn-outline-secondary border-0"
                                href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"
                                target="_blank" data-bs-toggle="tooltip"
                                data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-body p-0"></div></div>'
                                title="Facebook" aria-label="Share on Facebook">
                                <i class="ci-facebook"></i>
                            </a>

                            <!-- Telegram Share -->
                            <a class="btn btn-icon fs-base btn-outline-secondary border-0"
                                href="https://t.me/share/url?url=<?php echo e(urlencode(url()->current())); ?>" target="_blank"
                                data-bs-toggle="tooltip"
                                data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-body p-0"></div></div>'
                                title="Telegram" aria-label="Share on Telegram">
                                <i class="ci-telegram"></i>
                            </a>
                        </div>

                    </div>

                    <!-- Post navigation -->
                    
                </div>


                <!-- Sharing sticky sidebar visible on screens > 991px wide (lg breakpoint) -->
                <aside class="col-lg-2 d-none d-lg-block" style="margin-top: -115px">
                    <div class="sticky-top" style="padding-top: 115px">
                        <div class="d-flex flex-column align-items-center gap-2">
                            <div class="text-body-emphasis fs-sm fw-medium">Share:</div>
                            <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(url()->current())); ?>"
                                data-bs-toggle="tooltip" data-bs-placement="left"
                                data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-body p-0"></div></div>'
                                title="X (Twitter)" aria-label="Follow us on X">
                                <i class="ci-x"></i>
                            </a>
                            <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"
                                data-bs-toggle="tooltip" data-bs-placement="left"
                                data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-body p-0"></div></div>'
                                title="Facebook" aria-label="Follow us on Facebook">
                                <i class="ci-facebook"></i>
                            </a>
                            <a class="btn btn-icon fs-base btn-outline-secondary border-0" href="https://t.me/share/url?url=<?php echo e(urlencode(url()->current())); ?>"
                                data-bs-toggle="tooltip" data-bs-placement="left"
                                data-bs-template='<div class="tooltip fs-xs mb-n2" role="tooltip"><div class="tooltip-inner bg-transparent text-body p-0"></div></div>'
                                title="Telegram" aria-label="Follow us on Telegram">
                                <i class="ci-telegram"></i>
                            </a>
                        </div>
                    </div>
                </aside>
            </div>
        </section>


        <!-- Related articles that turn into slider on screens < 992px wide (lg breakpoint) -->
        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/blog-post.blade.php ENDPATH**/ ?>