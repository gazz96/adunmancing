

<?php $__env->startSection('content'); ?>
    <!-- Page content -->
    <main class="content-wrapper">

        <!-- Hero slider -->
        


        <!-- Categories -->
        <section class="container py-5 my-2 my-sm-3 mb-md-2 mt-lg-4 my-xl-5">
            <div class="overflow-x-auto pt-xxl-3">
                <div class="row flex-nowrap flex-md-wrap justify-content-md-center g-0 gap-4 gap-md-0">

                    <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Category -->
                        <div class="col col-md-4 col-lg-3 col-xl-2 mb-4">
                            <div class="category-card w-100 text-center px-1 px-lg-2 px-xxl-3 mx-auto"
                                style="min-width: 165px">
                                <div class="category-card-body-x">
                                    <a class="d-block text-decoration-none"
                                        href="<?php echo e(route('web.shop', [
                                            'category_id' => $productCategory->id,
                                        ])); ?>">
                                        <div class="bg-body-tertiary rounded-pill mb-3 mx-auto" style="max-width: 164px">
                                            <div class="ratio ratio-1x1">
                                                <img src="<?php echo e(asset('storage/' . $productCategory->icon)); ?>"
                                                    class="rounded-pill" alt="Image">
                                            </div>
                                        </div>
                                        <h3 class="category-card-title h6 text-truncate"><?php echo e($productCategory->name); ?>

                                        </h3>
                                    </a>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>


        <!-- Popular products carousel -->
        <section class="container pb-5 mt-md-n2 mb-2 mb-sm-3 mb-md-4 mb-xl-5">

            <!-- Heading -->
            <div class="d-flex align-items-center justify-content-between border-bottom pb-3 pb-md-4">
                <h2 class="h3 mb-0">Product Terbaru</h2>
                <div class="nav ms-3">
                    <a class="nav-link animate-underline px-0 py-2" href="<?php echo e(route('web.shop')); ?>">
                        <span class="animate-target">View all</span>
                        <i class="ci-chevron-right fs-base ms-1"></i>
                    </a>
                </div>
            </div>

            <!-- Product carousel -->
            <div class="position-relative pb-xxl-3">

                <!-- External slider prev/next buttons visible on screens > 500px wide (sm breakpoint) -->
                <button type="button"
                    class="popular-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start position-absolute top-50 start-0 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                    aria-label="Prev">
                    <i class="ci-chevron-left fs-lg animate-target"></i>
                </button>
                <button type="button"
                    class="popular-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end position-absolute top-50 start-100 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                    aria-label="Next">
                    <i class="ci-chevron-right fs-lg animate-target"></i>
                </button>

                <!-- Slider -->
                <div class="swiper pt-3 pt-sm-4"
                    data-swiper='{
                        "slidesPerView": 2,
                        "spaceBetween": 24,
                        "loop": true,
                        "navigation": {
                        "prevEl": ".popular-prev",
                        "nextEl": ".popular-next"
                        },
                        "breakpoints": {
                        "768": {
                            "slidesPerView": 3
                        },
                        "992": {
                            "slidesPerView": 4
                        }
                        }
                    }'>
                    <div class="swiper-wrapper">

                        <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Item -->
                        <div class="swiper-slide">
                            <div class="animate-underline mb-sm-2">
                                
                                <a class="ratio ratio-1x1 d-block mb-3" href="<?php echo e($newProduct->permalink); ?>">
                                    <?php if($newProduct->compare_price): ?>
                                    <div class="position-absolute top-0 start-0 z-2 mt-2 mt-sm-3 ms-2 ms-sm-3">
                                        <span class="badge text-bg-danger">-<?php echo e($newProduct->percentage_discount_by_compare_price); ?>%</span>
                                    </div>
                                    <?php endif; ?>
                                    <img src="<?php echo e($newProduct->featured_image_url); ?>" class="hover-effect-target opacity-100"
                                        alt="<?php echo e($newProduct->name); ?>">
                                    <img src="assets/img/shop/furniture/01-hover.jpg"
                                        class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                        alt="Room">
                                </a>
                                
                                <h3 class="mb-2">
                                    <a class="d-block fs-sm fw-medium text-truncate" href="<?php echo e($newProduct->permalink); ?>">
                                        <span class="animate-target"><?php echo e($newProduct->name); ?></span>
                                    </a>
                                </h3>
                                <div class="h6"><?php echo e($newProduct->price_label); ?>

                                    <?php if($newProduct->compare_price): ?>
                                    <span class="text-body-secondary text-decoration-line-through ms-1"><?php echo e($newProduct->compare_price_label); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="d-flex gap-2">
                                    <?php if($newProduct->attributes->count()): ?>
                                    <a href="<?php echo e($newProduct->permalink); ?>" class="btn btn-dark w-100 rounded-pill px-3">Lihat</a>
                                    <?php else: ?> 
                                    <button type="button" class="btn btn-dark w-100 rounded-pill px-3 btn-single_add_to_cart" data-key="<?php echo e($newProduct->id); ?>">Add to cart</button>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>

            <!-- External slider prev/next buttons visible on screens < 500px wide (sm breakpoint) -->
            <div class="d-flex justify-content-center gap-2 mt-1 pt-4 d-sm-none">
                <button type="button"
                    class="popular-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start me-1"
                    aria-label="Prev">
                    <i class="ci-chevron-left fs-lg animate-target"></i>
                </button>
                <button type="button"
                    class="popular-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end"
                    aria-label="Next">
                    <i class="ci-chevron-right fs-lg animate-target"></i>
                </button>
            </div>
        </section>

        <!-- Makanan products carousel -->
        <section class="container pb-5 mt-md-n2 mb-2 mb-sm-3 mb-md-4 mb-xl-5">

            <!-- Heading -->
            <div class="d-flex align-items-center justify-content-between border-bottom pb-3 pb-md-4">
                <h2 class="h3 mb-0">Umpan</h2>
                <div class="nav ms-3">
                    <a class="nav-link animate-underline px-0 py-2" href="<?php echo e(route('web.shop', [
                    'category_id' => 1])); ?>">
                        <span class="animate-target">View all</span>
                        <i class="ci-chevron-right fs-base ms-1"></i>
                    </a>
                </div>
            </div>

            <!-- Product carousel -->
            <div class="position-relative pb-xxl-3">

                <!-- External slider prev/next buttons visible on screens > 500px wide (sm breakpoint) -->
                <button type="button"
                    class="popular-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start position-absolute top-50 start-0 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                    aria-label="Prev">
                    <i class="ci-chevron-left fs-lg animate-target"></i>
                </button>
                <button type="button"
                    class="popular-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end position-absolute top-50 start-100 z-2 translate-middle mt-n5 d-none d-sm-inline-flex"
                    aria-label="Next">
                    <i class="ci-chevron-right fs-lg animate-target"></i>
                </button>

                <!-- Slider -->
                <div class="swiper pt-3 pt-sm-4"
                    data-swiper='{
                        "slidesPerView": 2,
                        "spaceBetween": 24,
                        "loop": true,
                        "navigation": {
                        "prevEl": ".popular-prev",
                        "nextEl": ".popular-next"
                        },
                        "breakpoints": {
                        "768": {
                            "slidesPerView": 3
                        },
                        "992": {
                            "slidesPerView": 4
                        }
                        }
                    }'>
                    <div class="swiper-wrapper">

                        <?php $__currentLoopData = $makanProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Item -->
                        <div class="swiper-slide">
                            <div class="animate-underline mb-sm-2">
                                
                                <a class="ratio ratio-1x1 d-block mb-3" href="<?php echo e($newProduct->permalink); ?>">
                                    <?php if($newProduct->compare_price): ?>
                                    <div class="position-absolute top-0 start-0 z-2 mt-2 mt-sm-3 ms-2 ms-sm-3">
                                        <span class="badge text-bg-danger">-<?php echo e($newProduct->percentage_discount_by_compare_price); ?>%</span>
                                    </div>
                                    <?php endif; ?>
                                    <img src="<?php echo e($newProduct->featured_image_url); ?>" class="hover-effect-target opacity-100"
                                        alt="<?php echo e($newProduct->name); ?>">
                                    <img src="assets/img/shop/furniture/01-hover.jpg"
                                        class="position-absolute top-0 start-0 hover-effect-target opacity-0 rounded-4"
                                        alt="Room">
                                </a>
                                
                                <h3 class="mb-2">
                                    <a class="d-block fs-sm fw-medium text-truncate" href="<?php echo e($newProduct->permalink); ?>">
                                        <span class="animate-target"><?php echo e($newProduct->name); ?></span>
                                    </a>
                                </h3>
                                <div class="h6"><?php echo e($newProduct->price_label); ?>

                                    <?php if($newProduct->compare_price): ?>
                                    <span class="text-body-secondary text-decoration-line-through ms-1"><?php echo e($newProduct->compare_price_label); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="d-flex gap-2">
                                    <?php if($newProduct->attributes->count()): ?>
                                    <a href="<?php echo e($newProduct->permalink); ?>" class="btn btn-dark w-100 rounded-pill px-3">Lihat</a>
                                    <?php else: ?> 
                                    <button type="button" class="btn btn-dark w-100 rounded-pill px-3 btn-single_add_to_cart" data-key="<?php echo e($newProduct->id); ?>">Add to cart</button>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>

            <!-- External slider prev/next buttons visible on screens < 500px wide (sm breakpoint) -->
            <div class="d-flex justify-content-center gap-2 mt-1 pt-4 d-sm-none">
                <button type="button"
                    class="popular-prev btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-start me-1"
                    aria-label="Prev">
                    <i class="ci-chevron-left fs-lg animate-target"></i>
                </button>
                <button type="button"
                    class="popular-next btn btn-icon btn-outline-secondary bg-body rounded-circle animate-slide-end"
                    aria-label="Next">
                    <i class="ci-chevron-right fs-lg animate-target"></i>
                </button>
            </div>
        </section>



        <!-- Gallery -->
        <!--
            <section class="container pb-5 mb-sm-2 mb-md-3 mb-lg-4 mb-xl-5">
                <h2 class="h3 pb-3">Interior design and inspiration</h2>

                <nav class="overflow-x-auto mb-3" data-simplebar data-simplebar-auto-hide="false">
                    <ul class="nav nav-pills flex-nowrap text-nowrap pb-3">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#!">Living room</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#!">Bedroom</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#!">Kitchen</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#!">Decoration</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#!">Office</a>
                        </li>
                    </ul>
                </nav>

                <div class="row g-4 g-sm-3 g-lg-4 mb-xxl-3">
                    <div class="col-sm-5 d-flex flex-column gap-4 gap-sm-3 gap-lg-4">

                        <div class="ratio" id="hotspots" style="--cz-aspect-ratio: calc(500 / 526 * 100%)">
                            <a class="btn btn-icon btn-sm btn-light rounded-circle shadow position-absolute z-2 d-none-rtl"
                                href="#!" style="top: 63.4%; left: 75.8%" data-bs-toggle="popover" data-bs-html="true"
                                data-bs-trigger="focus" data-bs-placement="top" data-bs-custom-class="popover-sm"
                                data-bs-content='
                <div class="d-flex align-items-start position-relative">
                  <img src="assets/img/home/furniture/gallery/hotspot01.png" width="64" alt="Image">
                  <div class="nav flex-column pt-2 ps-2 ms-1">
                    <a class="nav-link hover-effect-underline stretched-link p-0 mb-2" href="shop-product-furniture.html">Indigo coushy low sofa</a>
                    <div class="h6 mb-0">$856.00</div>
                  </div>
                </div>
              '
                                tabindex="1" aria-label="Hotspot">
                                <i class="ci-plus fs-sm"></i>
                            </a>
                            <a class="btn btn-icon btn-sm btn-light rounded-circle shadow position-absolute z-2 d-none d-flex-rtl"
                                href="#!" style="top: 63.4%; right: 18.5%" data-bs-toggle="popover" data-bs-html="true"
                                data-bs-trigger="focus" data-bs-placement="top" data-bs-custom-class="popover-sm"
                                data-bs-content='
                <div class="d-flex align-items-start position-relative">
                  <img src="assets/img/home/furniture/gallery/hotspot01.png" width="64" alt="Image">
                  <div class="nav flex-column pt-2 ps-2 ms-1">
                    <a class="nav-link hover-effect-underline stretched-link p-0 mb-2" href="shop-product-furniture.html">Indigo coushy low sofa</a>
                    <div class="h6 mb-0">$856.00</div>
                  </div>
                </div>
              '
                                tabindex="1" aria-label="Hotspot">
                                <i class="ci-plus fs-sm"></i>
                            </a>
                            <a class="btn btn-icon btn-sm btn-light rounded-circle shadow position-absolute z-2 d-none-rtl"
                                href="#!" style="top: 60.2%; left: 15.7%" data-bs-toggle="popover" data-bs-html="true"
                                data-bs-trigger="focus" data-bs-placement="bottom" data-bs-custom-class="popover-sm"
                                data-bs-content='
                <div class="d-flex align-items-start position-relative">
                  <img src="assets/img/home/furniture/gallery/hotspot02.png" width="64" alt="Image">
                  <div class="nav flex-column pt-2 ps-2 ms-1">
                    <a class="nav-link hover-effect-underline stretched-link p-0 mb-2" href="shop-product-furniture.html">Ergonomic beige armchair</a>
                    <div class="h6 mb-0">$235.00</div>
                  </div>
                </div>
              '
                                tabindex="1" aria-label="Hotspot">
                                <i class="ci-plus fs-sm"></i>
                            </a>
                            <a class="btn btn-icon btn-sm btn-light rounded-circle shadow position-absolute z-2 d-none d-flex-rtl"
                                href="#!" style="top: 60%; right: 78%" data-bs-toggle="popover" data-bs-html="true"
                                data-bs-trigger="focus" data-bs-placement="bottom" data-bs-custom-class="popover-sm"
                                data-bs-content='
                <div class="d-flex align-items-start position-relative">
                  <img src="assets/img/home/furniture/gallery/hotspot02.png" width="64" alt="Image">
                  <div class="nav flex-column pt-2 ps-2 ms-1">
                    <a class="nav-link hover-effect-underline stretched-link p-0 mb-2" href="shop-product-furniture.html">Ergonomic beige armchair</a>
                    <div class="h6 mb-0">$235.00</div>
                  </div>
                </div>
              '
                                tabindex="1" aria-label="Hotspot">
                                <i class="ci-plus fs-sm"></i>
                            </a>
                            <a class="btn btn-icon btn-sm btn-light rounded-circle shadow position-absolute z-2 start-50 translate-middle-x"
                                href="#!" style="top: 25.8%" data-bs-toggle="popover" data-bs-html="true"
                                data-bs-trigger="focus" data-bs-placement="top" data-bs-custom-class="popover-sm"
                                data-bs-content='
                <div class="d-flex align-items-start position-relative">
                  <img src="assets/img/home/furniture/gallery/hotspot03.png" width="64" alt="Image">
                  <div class="nav flex-column pt-2 ps-2 ms-1">
                    <a class="nav-link hover-effect-underline stretched-link p-0 mb-2" href="shop-product-furniture.html">Waves modern painting</a>
                    <div class="h6 mb-0">$74.99</div>
                  </div>
                </div>
              '
                                tabindex="1" aria-label="Hotspot">
                                <i class="ci-plus fs-sm"></i>
                            </a>
                            <img src="assets/img/home/furniture/gallery/01.jpg" class="rounded-5" alt="Image">
                        </div>

                        <div class="ratio" style="--cz-aspect-ratio: calc(529 / 526 * 100%)">
                            <img src="assets/img/home/furniture/gallery/02.jpg" class="rounded-5" alt="Image">
                        </div>
                    </div>
                    <div class="col-sm-7 d-flex flex-column gap-4 gap-sm-3 gap-lg-4">

                        <div class="ratio" style="--cz-aspect-ratio: calc(664 / 746 * 100%)">
                            <img src="assets/img/home/furniture/gallery/03.jpg" class="rounded-5" alt="Image">
                        </div>

                        <div class="ratio" style="--cz-aspect-ratio: calc(365 / 746 * 100%)">
                            <img src="assets/img/home/furniture/gallery/04.jpg" class="rounded-5" alt="Image">
                        </div>
                    </div>
                </div>
            </section>

          -->


        <!-- Features -->
        

        
            
          


        <!-- Blog grid -->
        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/index.blade.php ENDPATH**/ ?>