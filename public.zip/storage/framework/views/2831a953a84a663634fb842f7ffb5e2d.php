

<?php $__env->startSection('content'); ?>

<!-- Page content -->
<main class="content-wrapper">
    <div class="container py-5 mt-n2 mt-sm-0">
        <div class="row pt-md-2 pt-lg-3 pb-sm-2 pb-md-3 pb-lg-4 pb-xl-5">

            <!-- Sidebar navigation that turns into offcanvas on screens < 992px wide (lg breakpoint) -->
            <aside class="col-lg-3">
                <?php echo $__env->make('frontend.my-account.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>


            <!-- Orders content -->
            <div class="col-lg-9">
                <div class="ps-lg-3 ps-xl-0">

                    <!-- Page title + Sorting selects -->
                    <div class="row align-items-center pb-3 pb-md-4 mb-md-1 mb-lg-2">
                        <div class="col-md-4 col-xl-6 mb-3 mb-md-0">
                            <h1 class="h2 me-3 mb-0">Orders</h1>
                        </div>
                        <div class="col-md-8 col-xl-6">
                            <form action="">
                                <div class="row row-cols-1 row-cols-sm-2 g-3 g-xxl-4 d-flex justify-content-end">
                                    <div class="col">
                                        <select name="status" class="form-select"
                                            data-select='{
                                                "placeholderValue": "Select status",
                                                "choices": [
                                                {
                                                    "value": "",
                                                    "label": "Select status",
                                                    "placeholder": true
                                                },
                                                {
                                                    "value": "pending",
                                                    "label": "<div class=\"d-flex align-items-center text-nowrap\"><span class=\"bg-info rounded-circle p-1 me-2\"></span>Pending</div>"
                                                },
                                                {
                                                    "value": "delivered",
                                                    "label": "<div class=\"d-flex align-items-center text-nowrap\"><span class=\"bg-success rounded-circle p-1 me-2\"></span>Delivered</div>"
                                                },
                                                {
                                                    "value": "canceled",
                                                    "label": "<div class=\"d-flex align-items-center text-nowrap\"><span class=\"bg-danger rounded-circle p-1 me-2\"></span>Canceled</div>"
                                                },
                                                {
                                                    "value": "delayed",
                                                    "label": "<div class=\"d-flex align-items-center text-nowrap\"><span class=\"bg-warning rounded-circle p-1 me-2\"></span>Delayed</div>"
                                                }
                                                ]
                                            }'
                                            data-select-template="true" aria-label="Status sorting" onchange="this.form.submit()"></select>
                                    </div>
                                    
                                </div>
                            </form>
                        </div>
                    </div>


                    <!-- Sortable orders table -->
                    <div
                        data-filter-list='{"listClass": "orders-list", "sortClass": "orders-sort", "valueNames": ["date", "total"]}'>
                        <table class="table align-middle fs-sm text-nowrap">
                            <thead>
                                <tr>
                                    <th scope="col" class="py-3 ps-0">
                                        <span class="text-body fw-normal">Order <span
                                                class="d-none d-md-inline">#</span></span>
                                    </th>
                                    <th scope="col" class="py-3 d-none d-md-table-cell">
                                        <button type="button" class="btn orders-sort fw-normal text-body p-0"
                                            
                                            >Order date</button>
                                    </th>
                                    <th scope="col" class="py-3 d-none d-md-table-cell">
                                        <span class="text-body fw-normal">Status</span>
                                    </th>
                                    <th scope="col" class="py-3 d-none d-md-table-cell">
                                        <button type="button" class="btn orders-sort fw-normal text-body p-0"
                                            
                                            >Total</button>
                                    </th>
                                    <th scope="col" class="py-3">&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody class="text-body-emphasis orders-list">
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Item -->
                                <tr>
                                    <td class="fw-medium pt-2 pb-3 py-md-2 ps-0">
                                        <a class="d-inline-block animate-underline text-body-emphasis text-decoration-none py-2"
                                            href="#orderDetails" data-bs-toggle="offcanvas" aria-controls="orderDetails"
                                            aria-label="Show order details">
                                            <span class="animate-target"><?php echo e($order->order_number); ?></span>
                                        </a>
                                        <ul class="list-unstyled fw-normal text-body m-0 d-md-none">
                                            <li><?php echo e(date('d F Y', strtotime($order->created_at))); ?></li>
                                            <li class="d-flex align-items-center">
                                                <span class="bg-info rounded-circle p-1 me-2"></span>
                                                <?php echo e($order->status); ?>

                                            </li>
                                            <li class="fw-medium text-body-emphasis"><?php echo e(number_format($order->total)); ?></li>
                                        </ul>
                                    </td>
                                    <td class="fw-medium py-3 d-none d-md-table-cell">
                                        <?php echo e(date('d F Y', strtotime($order->created_at))); ?>

                                        <span class="date d-none"><?php echo e(date('Y-m-d', strtotime($order->created_at))); ?></span>
                                    </td>
                                    <td class="fw-medium py-3 d-none d-md-table-cell">
                                        <span class="d-flex align-items-center">
                                            <span class="bg-info rounded-circle p-1 me-2"></span>
                                            <?php echo e($order->status); ?>

                                        </span>
                                    </td>
                                    <td class="fw-medium py-3 d-none d-md-table-cell">
                                        <?php echo e(number_format($order->total)); ?>

                                        <span class="total d-none"><?php echo e(number_format($order->total)); ?></span>
                                    </td>
                                    <td class="py-3 pe-0">
                                        <span
                                            class="d-flex align-items-center justify-content-end position-relative gap-1 gap-sm-2 ms-n2 ms-sm-0">
                                            
                                            <a class="btn btn-icon btn-ghost btn-secondary stretched-link border-0"
                                                href="#orderDetails-<?php echo e($order->id); ?>" data-bs-toggle="offcanvas"
                                                aria-controls="orderDetails" aria-label="Show order details">
                                                <i class="ci-chevron-right fs-lg"></i>
                                            </a>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                    <!-- Pagination -->
                    
                </div>
            </div>
        </div>
    </div>
</main>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_scripts'); ?>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Order details offcanvas -->
    <div class="offcanvas offcanvas-end pb-sm-2 px-sm-2" id="orderDetails-<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="orderDetailsLabel" style="width: 500px">

      <!-- Header -->
      <div class="offcanvas-header align-items-start py-3 pt-lg-4">
        <div>
          <h4 class="offcanvas-title mb-1" id="orderDetailsLabel">Order # <?php echo e($order->order_number); ?></h4>
          <span class="d-flex align-items-center fs-sm fw-medium text-body-emphasis">
            <span class="bg-info rounded-circle p-1 me-2"></span>
            <?php echo e($order->status); ?>

          </span>
        </div>
        <button type="button" class="btn-close mt-0" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>

      <!-- Body -->
      <div class="offcanvas-body d-flex flex-column gap-4 pt-2 pb-3">

        <!-- Items -->
        <div class="d-flex flex-column gap-3">
        
          <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->product): ?>
            <!-- Item -->
            <div class="d-flex align-items-center">
                <a class="flex-shrink-0" href="<?php echo e($item->product->permalink); ?>">
                <img src="<?php echo e($item->product->featured_image_url); ?>" width="110" alt="<?php echo e($item->product->name); ?>">
                </a>
                <div class="w-100 min-w-0 ps-2 ps-sm-3">
                <h5 class="d-flex animate-underline mb-2">
                    <a class="d-block fs-sm fw-medium text-truncate animate-target" href="shop-product-general-electronics.html"><?php echo e($item->product->name); ?></a>
                </h5>
                <div class="h6 mb-2"><?php echo e(number_format($item->price)); ?></div>
                <div class="fs-xs">Qty: <?php echo e($item->quantity); ?></div>
                </div>
            </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


        <!-- Delivery + Payment info -->
        <div class="border-top pt-4">
          <h6>Delivery</h6>
          <ul class="list-unstyled fs-sm mb-4">
            <li class="d-flex justify-content-between mb-1">
              Estimated delivery:
              <span class="text-body-emphasis fw-medium text-end ms-2"><?php echo e($order->courier_package_data[3] ?? ''); ?> days</span>
            </li>
            <li class="d-flex justify-content-between mb-1">
              Shipping method:
              <span class="text-body-emphasis fw-medium text-end ms-2"><?php echo e(strtoupper($order->courier)); ?></span>
            </li>
            <li class="d-flex justify-content-between">
              Shipping address:
              <span class="text-body-emphasis fw-medium text-end ms-2"><?php echo e($order->address); ?>, <?php echo e($order->postal_code); ?></span>
            </li>
          </ul>
          <h6>Payment</h6>
          <ul class="list-unstyled fs-sm m-0">
        
            <li class="d-flex justify-content-between">
              Shipping:
              <span class="text-body-emphasis fw-medium text-end ms-2"><?php echo e(number_format($order->delivery_price)); ?></span>
            </li>
          </ul>
        </div>

        <!-- Total -->
        <div class="d-flex align-items-center justify-content-between fs-sm border-top pt-4">
          Estimated total:
          <span class="h5 text-end ms-2 mb-0"><?php echo e(number_format($order->total)); ?></span>
        </div>
      </div>

      <!-- Footer -->
      
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/my-account/index.blade.php ENDPATH**/ ?>