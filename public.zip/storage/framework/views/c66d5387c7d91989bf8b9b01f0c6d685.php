


<?php $__env->startSection('content'); ?>
    <!-- Posts list + Sidebar -->
    <section class="container pb-5 mb-2 mb-md-3 mb-lg-4 mb-xl-5 mt-5">
        <div class="row">

            <!-- Posts list -->
            <div class="col-lg-8">
                <div class="d-flex flex-column gap-4 mt-n3">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Article -->
                    <article class="row align-items-start align-items-md-center gx-0 gy-4 pt-3">
                        <div class="col-sm-5 pe-sm-4">
                            <a class="ratio d-flex hover-effect-scale rounded overflow-hidden flex-md-shrink-0"
                                href="<?php echo e($post->permalink); ?>" style="--cz-aspect-ratio: calc(226 / 306 * 100%)">
                                <img src="<?php echo e($post->featured_image_url); ?>" class="hover-effect-target" alt="Read: <?php echo e($post->title); ?>">
                            </a>
                        </div>
                        <div class="col-sm-7">
                            <div class="nav align-items-center gap-2 pb-2 mt-n1 mb-1">
                                
                                <span class="text-body-tertiary fs-xs"><?php echo e(date('d F Y', strtotime($post->created_at))); ?></span>
                            </div>
                            <h3 class="h5 mb-2 mb-md-3">
                                <a class="hover-effect-underline" href="<?php echo e($post->permalink); ?>"><?php echo e($post->title); ?></a>
                            </h3>
                            <p class="mb-0"><?php echo e($post->excerpt); ?></p>
                        </div>
                    </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
    
                <!-- Pagination -->
                <div>
                    <?php echo e($posts->links()); ?>

                </div>
                
            </div>


            <!-- Sticky sidebar that turns into offcanvas on screens < 992px wide (lg breakpoint) -->
            <aside class="col-lg-4 col-xl-3 offset-xl-1" style="margin-top: -115px">
                <div class="offcanvas-lg offcanvas-end sticky-lg-top ps-lg-4 ps-xl-0" id="blogSidebar">
                    <div class="d-none d-lg-block" style="height: 115px"></div>
                    <div class="offcanvas-header py-3">
                        <h5 class="offcanvas-title">Sidebar</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                            data-bs-target="#blogSidebar" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body d-block pt-2 py-lg-0">
                        <h4 class="h6 mb-4">Blog categories</h4>
                        <div class="d-flex flex-wrap gap-3">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="btn btn-outline-secondary px-3" href="?category_id=<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <h4 class="h6 pt-5 mb-0">Trending posts</h4>
                        <?php $__currentLoopData = $trendingPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trendingPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="hover-effect-scale position-relative d-flex align-items-center border-bottom py-4">
                            <div class="w-100 pe-3">
                                <h3 class="h6 lh-base fs-sm mb-0">
                                    <a class="hover-effect-underline stretched-link" href="<?php echo e($trendingPost->permalink); ?>"><?php echo e($trendingPost->title); ?></a>
                                </h3>
                            </div>
                            <div class="ratio w-100" style="max-width: 86px; --cz-aspect-ratio: calc(64 / 86 * 100%)">
                                <img src="<?php echo e($trendingPost->featured_image_url); ?>" class="rounded-2" alt="<?php echo e($trendingPost->title); ?>">
                            </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </aside>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adunmancing\resources\views/frontend/blogs.blade.php ENDPATH**/ ?>