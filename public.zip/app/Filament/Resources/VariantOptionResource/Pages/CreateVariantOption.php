<?php

namespace App\Filament\Resources\VariantOptionResource\Pages;

use App\Filament\Resources\VariantOptionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateVariantOption extends CreateRecord
{
    protected static string $resource = VariantOptionResource::class;
}
